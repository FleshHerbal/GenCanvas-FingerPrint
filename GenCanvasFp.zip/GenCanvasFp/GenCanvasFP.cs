﻿using System;
using System.IO;
using System.Threading;
using Leaf.xNet;

namespace GenCanvasFp
{
    class GenCanvasFP
    {
        static void Main()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            
            GenCanvasFP genCanvas = new GenCanvasFP();
            string fileChange;
            string deleteFiles;

            Console.WriteLine("Укажите название папки для сохранения в 'С:/FingerPrints/' ");
            fileChange = Console.ReadLine().ToString() + "\\";
            string wey = "C:\\FingerPrints\\" + fileChange;

            Console.WriteLine("Укажите количество генерируемых файлов");
            int length;
            length = int.Parse(Console.ReadLine());

            DirectoryInfo directoryInfo = new DirectoryInfo(wey);
            directoryInfo.Create();

            Console.WriteLine(wey);

            for (int i = 0; i < length; i++)
            {
                Random rnd = new Random();
                 int x = rnd.Next(20000, 50000);
                string namefile = x.ToString() + i.ToString() + 250.ToString() + ".txt";

                string result = genCanvas.SetLogic("https://fingerprints.bablosoft.com/prepare?version=4&tags=Microsoft%20Windows%2CChrome");

                using (StreamWriter sw = new StreamWriter(wey + namefile, false, System.Text.Encoding.Default))
                {
                    sw.Write(result);
                }
                int a = 1 + i;
                Console.WriteLine("Генерирую фингерпринт:_" + a.ToString());
                Console.WriteLine("");
                Console.WriteLine("Жду 3-4 минуты;");

                Thread.Sleep(2000);
            }

            Console.WriteLine("Если в процессе сгенерировались пустые файлы, введи команду: deleteNull");
            deleteFiles = Console.ReadLine();

            if (deleteFiles == "deleteNull")
            {
                int val = 0;
                string[] iDir = Directory.GetFiles(wey);

                Console.WriteLine(wey);
                for (int i = 0; i < iDir.Length; i++)
                {
                    Console.WriteLine(Convert.ToString(iDir[i]));
                    FileInfo fInfo = new FileInfo(Convert.ToString(iDir[i]));
                    if (fInfo.Length <= 10240)
                    {
                        Console.WriteLine("Удаляю файл:" + "(" + fInfo.Length + ".kб):" + fInfo.ToString());
                        var del = fInfo;
                        File.Delete(del.ToString());

                        val++;
                    }
                    Console.WriteLine("Файлов удалено:" + val);
                }
                Console.ReadKey();
            }
            else
                Console.WriteLine("111");
        }
        public string SetLogic(string url)
        {
            HttpRequest request = new HttpRequest();

            string responce;

            request.AddHeader(HttpHeader.Accept, "*/*");
            request.AddHeader("Accept-Encoding", "gzip, deflate");

            responce = request.Get(url).ToString();

            return responce;
        }
    }
}
